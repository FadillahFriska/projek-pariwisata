# PHP MySQL
Contoh latihan Pemrograman Web (PHP dan MySQL)
## Cara install
1. Download atau Clode repo ini
2. Tempatkan folder (repo ini) di `htdocs`
3. Import database (file `database.sql` dan `user.sql`) yang berada di folder `akademik`, nama database di MySQL: `akademik`
4. Pastikan service webserver Apache dan Mysql sudah dijalankan
5. Buka http://localhost/folder_di_htdocs
6. Username untuk masuk ke dashboard admin adalah: `admin` dan passwordnya: `admin`

Semua file di direktori `admin` tidak dapat diakses jika belum login

