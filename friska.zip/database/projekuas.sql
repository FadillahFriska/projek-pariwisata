-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 24, 2024 at 08:16 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `projekuas`
--

-- --------------------------------------------------------

--
-- Table structure for table `destinasi`
--

CREATE TABLE `destinasi` (
  `Id_destinasi` int(11) NOT NULL,
  `nama_destinasi` varchar(50) NOT NULL,
  `tanggal_buka` date NOT NULL,
  `lokasi` varchar(25) NOT NULL,
  `deskripsi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `destinasi`
--

INSERT INTO `destinasi` (`Id_destinasi`, `nama_destinasi`, `tanggal_buka`, `lokasi`, `deskripsi`) VALUES
(1, 'Pantai Bunga', '2014-02-04', 'Tanjung Tiram', 'Pantai Bunga Kabupaten Batu Bara adalah salah satu kabupaten yang ada di sumatera utara dan beribu kota di kecamatan LimaPuluh yang merupakan dari 16 kabupaten.\r\n\r\nKabupaten ini terletak di tepi pantai selat malaka , sekitar 175 km '),
(2, 'pantai jono', '2014-02-04', 'Tanjung Tiram', 'pantai jono/perjuangan berada didesa lalang,kecamatan medang deras,kabupaten batu bara, sumatra utara.wisata dari medan dapat melalui tol'),
(3, 'pantai perupuk', '2014-02-04', 'Tanjung Tiram', 'pantai perupuk cukup populer namanya bagi warga kabupaten batubara sumatra utara namun mungkin belum banyak diketahui oleh traveler nusantara lainnya'),
(4, 'pulau pandang', '2032-02-10', 'Tanjung Tiram', 'pulau pandang cukup populer namanya bagi warga kabupaten batubara sumatra utara namun mungkin belum banyak diketahui oleh traveler nusantara lainnya dimanakah lokasinnya dan apa daya tariknya tahun 1978-1979,\r\npantai indah ini beralih fungsi menjadi tempat pemijahan berbentuk tambak sistem permanen dengan atap kaca.');

-- --------------------------------------------------------

--
-- Table structure for table `komentar`
--

CREATE TABLE `komentar` (
  `komentar_id` int(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `pesan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `komentar`
--

INSERT INTO `komentar` (`komentar_id`, `nama`, `email`, `pesan`) VALUES
(1, 'friska', 'fadillafriska@gmail.com', ' halo'),
(2, 'sania', 'fadillafriska@gmail.com', ' hvvjh'),
(3, 'erny', 'fadillafriska40@gmail.com', ' khwjjjfj'),
(4, 'dwi fadilla', 'fadillafriska@gmail.com', ' jhfhuii'),
(5, 'awwah', 'fadillafriska40@gmail.com', ' bmdshui'),
(6, 'awwah', 'fadillafriska40@gmail.com', ' grty'),
(7, 'seny', 'fadillafriska40@gmail.com', ' tempat ddk'),
(8, 'polan', 'fadillafriska@gmail.com', ' tempat ddk'),
(9, 'awwah', 'fadillafriska40@gmail.com', ' gyr'),
(10, 'polan', 'fadillafriska40@gmail.com', ' ddk');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(254) NOT NULL,
  `email` varchar(50) NOT NULL,
  `token` char(128) DEFAULT NULL,
  `status` char(1) DEFAULT NULL,
  `last_login` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `username`, `password`, `email`, `token`, `status`, `last_login`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'fadillafriska40@gmail.com', 'c0e024d9200b5705bc4804722636378a', '1', '2024-02-24 13:03:24');

-- --------------------------------------------------------

--
-- Table structure for table `wisata`
--

CREATE TABLE `wisata` (
  `id_pariwisata` int(11) NOT NULL,
  `Nama` varchar(50) NOT NULL,
  `alamat` varchar(50) NOT NULL,
  `pengurus` varchar(50) NOT NULL,
  `keterangan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `wisata`
--

INSERT INTO `wisata` (`id_pariwisata`, `Nama`, `alamat`, `pengurus`, `keterangan`) VALUES
(1, 'Pantai Jono', 'Batu Bara', 'Erni', 'pantai jono/perjuangan berada didesa lalang,kecamatan medang deras,kabupaten batu bara, sumatra utara.wisata dari medan'),
(2, 'pantai bunga', 'batu bara', 'awwah', 'pantai bunga batu bara adalah salah satu destinasi wisata yg menawarkan panorama alam yg indah dan sejarah yg menarik.'),
(3, 'pulau pandang', 'batu bara', 'sania', 'pulau pandang cukup populer namanya bagi warga kabupaten batubara sumatra utara namun mungkin belum banyak diketahui oleh traveler nusantara lainnya dimanakah lokasinnya dan apa daya tariknya.'),
(4, 'pantai perupuk', 'batu bara', 'justina', 'sebuah pantai yg berada di kecamatan batu bara sumatra utara menyimpan sejuta cerita dan kenangan bagi masyarakat sekitar');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `destinasi`
--
ALTER TABLE `destinasi`
  ADD PRIMARY KEY (`Id_destinasi`);

--
-- Indexes for table `komentar`
--
ALTER TABLE `komentar`
  ADD PRIMARY KEY (`komentar_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `wisata`
--
ALTER TABLE `wisata`
  ADD PRIMARY KEY (`id_pariwisata`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `destinasi`
--
ALTER TABLE `destinasi`
  MODIFY `Id_destinasi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `komentar`
--
ALTER TABLE `komentar`
  MODIFY `komentar_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `wisata`
--
ALTER TABLE `wisata`
  MODIFY `id_pariwisata` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
