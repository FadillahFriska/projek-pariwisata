7<?php include "header.php"; ?>
		<!-- Awal script Slider/ Carousel -->
		<div id="contoh-carousel" class="carousel slide" data-ride="carousel">
      <ol class="carousel-indicators">
        <li data-target="#contoh-carousel" data-slide-to="0" class="active"></li>
        <li data-target="#contoh-carousel" data-slide-to="1"></li>
        <li data-target="#contoh-carousel" data-slide-to="2"></li>
      </ol>

      <div class="carousel-inner" role="listbox">
			<!-- Awal script Slider pertama -->
        <div class="item active">
          <img src="images/pulau pandang.jpg" alt="Berisi keterangan gambar" style="width:200%; height: 500px ;">
          <div class="carousel-caption">
            <h1>Pariwisata kabupaten Batu-Bara</h1>
            <h4>Tempat Wisata</h4>
            <p>pariwisata kabupaten Batu-Bara</p>
            <a href="detail_slider1.php" class="btn btn-danger">Baca Lebih Lanjut</a>
          </div>
        </div><!-- Akhir script Slider pertama -->
				<!-- Awal script Slider kedua -->
        <div class="item">
          <img src="images/pantai bunga.jpg" alt="Berisi keterangan gambar" style="width:200%; height: 500px ;">
          <div class="carousel-caption">
            <h1>pariwisata kabupaten Batu-Bara</h1>
            <h4>Tempat Wisata</h4>
            <p>pariwisata kabupaten Batu-Bara</p>
            <a href="detail_slide.php" class="btn btn-danger">Baca Lebih Lanjut</a>
          </div>
        </div><!-- Akhir script Slider kedua -->
				<!-- Awal script Slider ketiga -->
        <div class="item">
          <img src="images/pantai jono.jpg" alt="Berisi keterangan gambar" style="width:200%; height: 500px ;">
          <div class="carousel-caption">
            <h1>pariwisata kabupaten Batu-Bara</h1>
            <h4>Tempat Wisata</h4>
            <p>pariwisata kabupaten Batu-Bara</p>
            <a href="detail_slide.php" class="btn btn-danger">Baca Lebih Lanjut</a>
          </div>
        </div><!-- Akhir script Slider ketiga -->
    </div>
		<!-- Awal script Button Geser Kiri dan Kanan -->
    <a class="left carousel-control" href="#contoh-carousel" role="button" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
    </a>
		
    <a class="right carousel-control" href="#contoh-carousel" role="button" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
    </a><!-- Akhir script Button Geser Kiri dan Kanan -->
		
    </div><!-- Akhir script Slider/Carousel -->
		
		<!-- Awal Jumbotron -->
		<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
					<div class="jumbotron">
						<h2>SELAMAT DATANG WISATA BATU BARA</h2>
						<p>NIKMATI KEINDAHAN ALAM DAN BUDAYA WISATA BATU BARA </p>
						<p><a class="btn btn-warning btn-lg" href="beasiswa_d3.php" role="button">Selengkapnya</a>
						<a class="btn btn-danger btn-lg" href="daftar_beasiswa.php"role="button">Daftar</a></p>
				</div>
      </div>
		</div>
		</div><!-- Akhir Jumbotron -->
		
		<!-- Awal Page -->
		<div class="container">
		<!-- Awal Panel -->
		<div class="row">
			<div class="panel panel-default">
				<div class="panel-body">
				<h2 style="text-muted"><span class="glyphicon glyphicon-list"></span>wisata batu bara</h2>
				
        <p>KABUPATEN BATU BARA PROVINSI BATU BARA</p>
				
				<div class="row">
					<div class="col-md-3">
					<h3>PULAU PANDANG</h3>
						<img src="images/pulau pandang.jpg" class="img-thumbnail img-responsive">
						<p>pulau pandang cukup populer namanya bagi warga kabupaten batubara sumatra utara namun mungkin belum banyak diketahui oleh traveler nusantara lainnya dimanakah lokasinnya dan apa daya tariknya.<br/><a class="btn btn-danger btn-xs" href="ruang-kelas.html"role="button">Selengkapnya</a></p>
					</div>
					<div class="col-md-3">
					<h3>PANTAI JONO</h3>
						<img src="images/pantai jono.jpg" class="img-thumbnail img-responsive">
						<p>pantai jono/perjuangan berada didesa lalang,kecamatan medang deras,kabupaten batu bara, sumatra utara.wisata dari medan dapat melalui tol.<br/><a class="btn btn-info btn-xs" href="pantai jono.php"role="button">Selengkapnya</a></p>
			
					</div>
				</div>
				</div>
      </div>
		</div><!-- Akhir Panel -->
		
