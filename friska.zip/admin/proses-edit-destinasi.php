<?php
  session_start();
  if (empty($_SESSION['user_id'])){
    header("location:../login.php");
  }
?>
<?php

include "../koneksi.php";

$id=$_POST['Id_destinasi'];
$nama_destinasi=$_POST['nama_destinasi'];
$tanggal_dibuka=$_POST['tanggal_dibuka'];
$lokasi=$_POST['lokasi'];
$deskripsi=$_POST['deskripsi'];

$ubah=$koneksi->query("update destinasi set nama_destinasi='$nama_destinasi', tanggal_dibuka='$tanggal_dibuka', lokasi='$lokasi', ndeskripsi='$deskripsi', where id_destinasi='$id'");

if($ubah==true){

    header("location:tampil-destinasi.php?pesan=editBerhasil");
} else{
    echo "Error";
}

?>