<?php
  session_start();
  if (empty($_SESSION['user_id'])){
    header("location:../login.php");
  }
?>
<?php

$nim=$_POST['nama_destinasi'];
$nama=$_POST['lokasi'];
$jenis_kelamin=$_POST['deskripsi'];
$alamat=$_POST['tanggal_dibuka'];
$alamat=$_POST['telepon'];
$alamat=$_POST['email'];

include "../koneksi.php";

$simpan=$koneksi->query("insert into destinasi(nama_destinasi,lokasi,deskripsi,tanggal_dibuka,telepon,email) 
                        values ('$nama_destinasi', '$lokasi', '$deskripsi', '$tanggal_dibuka', '$telepon','$email')");

if($simpan==true){

    header("location:tampil-Pariwisata.php?pesan=inputBerhasil");
} else{
    echo "Error";
}




?>