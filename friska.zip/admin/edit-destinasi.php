<?php
  session_start();
  if (empty($_SESSION['user_id'])){
    header("location:../login.php");
  }
?>
<?php include "header.php"; ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <form action="proses-edit-destinasi.php" method="POST">
                <?php
                $id=$_GET['id'];
                include "../koneksi.php";
                $tampil=$koneksi->query("select * from destinasi where Id_destinasi='$id'");
                $row=$tampil->fetch_assoc();
                ?>
                    <div class="form-group">
                        <label for="nama_destinasi">Nama Destinasi</label>
                        <input type="hidden" name="Id_destinasi" value="<?php echo $row['Id_destinasi']?>" class="form-control">
                        <input type="text" name="nama_destinasi" value="<?php echo $row['nama_destinasi']?>" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="tanggal_dibuka">Tanggal Buka</label>
                        <input type="date" name="tanggal_buka" value="<?php echo $row['tanggal_buka']?>" class="form-control">
                    </div>

                    <div class="form-group">
                        <label for="lokasi">Lokasi</label>
                        <textarea name="lokasi" class="form-control"><?php echo $row['lokasi']?></textarea>
                    </div>
                    <div class="form-group">
                        <label for="deskripsi">Deskripsi</label>
                        <input type="text" name="deskripsi" value="<?php echo $row['deskripsi']?>" class="form-control">
                    </div>

                    <input type="submit" name="kirim" value="UBAH" class="btn btn-info">
                    <input type="reset" name="kosongkan" value="Kosongkan" class="btn btn-danger">
                </form>
            </div>
        </div>
    </div>

<?php include "footer.php";?>