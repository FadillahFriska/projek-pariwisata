<?php include "header.php";?>
		<!-- Awal Page -->
		<div class="container">
		<!-- Awal baris -->
		<div class="row">
			<div class="col-md-16"><!-- Awal Kolom Pertama -->
			<div class="panel panel-default">
				<div class="panel-body">
				<h2 style="text-muted"><span class="glyphicon glyphicon-list"></span> ABOUT US</h2>
						<img src="images/pantai bunga.jpg" class="img-thumbnail img-responsive">
						<p>Kabupaten Batu Bara adalah salah satu kabupaten yang ada di sumatera utara dan beribu kota di kecamatan LimaPuluh yang merupakan dari 16 kabupaten. <br/><br/>
						Kabupaten ini terletak di tepi pantai selat malaka , sekitar 175 km selatan ibu kota medan. di kabupaten batu bara memiliki beberapa tempat pariwisata yaitu sebagai berikut:
						<ul>
						<li>pulau pandang</li>
						<li>Pulau Pandang cukup populer</li>
						<li>pantai jono </li>
						<li>pantai perupuk</li>
						<li>pantai bunga</li>
						</ul>
				</p>
				</div>
      </div>
			</div><!-- Akhir Kolom Pertama -->
			
			<div class="col-md-16"><!-- Awal kolom kedua -->
			<div class="panel panel-default">
				<div class="panel-body">
				<h2 style="text-muted"><span class="glyphicon glyphicon-tasks"></span>Info Lainnya</h2>
				<h4>pulau pandang</h4>
				<img src="images/pulau pandang.jpg" class="img-thumbnail img-responsive">
				<p>pulau pandang cukup populer namanya bagi warga kabupaten batubara sumatra utara namun mungkin belum banyak diketahui oleh traveler nusantara lainnya dimanakah lokasinnya dan apa daya tariknya <b>tahun 1978-1979,<br/> pantai indah ini beralih fungsi menjadi tempat pemijahan berbentuk tambak sistem permanen dengan atap kaca. <br/><a class="btn btn-danger btn-xs" href="wisata.html"role="button">pariwisata</a></p>
				</div>
      </div>
			</div><!-- Akhir Kolom Kedua -->
		</div><!-- Akhir Baris -->
		</div><!--  Akhir Page -->
