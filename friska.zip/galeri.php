<?php include "header.php"; ?>
		
		<!-- Awal Page -->
		<div class="container">
		<!-- Awal baris -->
		<div class="row">
			<div class="col-md-8"><!-- Awal Kolom Pertama -->
			<div class="panel panel-default">
				<div class="panel-body">
				<h2 style="text-muted"><span class="glyphicon glyphicon-list"></span> Galeri</h2>
					<div class="row">
						<div class="col-md-6">
							<img src="images/pantai perupuk.jpg" class="img-thumbnail img-responsive">
						</div>
						<div class="col-md-6">
						<img src="images/pantai bunga.jpg" class="img-thumbnail img-responsive">
						</div>
					</div>
					<div class="row">
						<div class="col-md-4">
							<img src="images/pulau pandang.jpg" class="img-rounded img-responsive">
						</div>
						<div class="col-md-4">
						<img src="images/pantai jono.jpg" class="img-rounded img-responsive">
						</div>
						<div class="col-md-4">
						<img src="images/pantai bunga.jpg" class="img-rounded img-responsive">
						</div>
					</div>
					<div class="row">
						<div class="col-md-3">
							<img src="images/pantai bunga.jpg" class="img-circle img-responsive">
						</div>
						<div class="col-md-3">
						<img src="images/pulau pandang.jpg" class="img-circle img-responsive">
						</div>
						<div class="col-md-3">
						<img src="images/pantai perupuk.jpg" class="img-circle img-responsive">
						</div>
						<div class="col-md-3">
						<img src="images/pantai jono.jpg" class="img-circle img-responsive">
						</div>
					</div>
					</div>
      </div>
		</div><!-- Akhir Baris -->
		</div><!--  Akhir Page -->